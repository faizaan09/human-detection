run('D:/Documents/Softwares and Libraries/vlfeat-0.9.21/toolbox/vl_setup');
vl_version verbose;
addpath(genpath('D:/Documents/Spring 2018/Machine Learning/hw2/human-detection/hw2data/'))